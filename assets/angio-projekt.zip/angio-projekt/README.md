# Angio – 3D-Angio-Untersuchungsraum

Interaktiver, schematischer Angio-Untersuchungsraum in 3D (React + Three.js / react-three-fiber).

## Inhalt der Szene

- Patientenliege mit Tischfuß, Tisch endet vor dem C-Bogen
- Patient: Körper mit elliptischem Querschnitt (2,5:1), Kopf, Beine, grünes Abdecktuch (Knöchel bis über Genitalbereich)
- C-Bogen mit Detektor (25 x 25 cm) oben, Röntgenröhre mit Brennfleck (Punktquelle) unten, divergierender Strahlenkegel; steht über dem Kopf, LAO/RAO-Drehung per Regler um die Patientenchse
- Deckengehaltene Bleiglasscheibe über der Brust (Brust-Ausschnitt mit 5 cm Abstand, 80 x 72 cm, um 20 % tischauswärts erweitert, senkrecht zur Verbindungslinie C-Bogen-Isozentrum – Untersucher:in gedreht)
- Vertikaler Untertischschutz in der Ebene der Bleiglasscheibe (ab Tischhöhe bis knapp über den Boden, dunkelgrau, undurchsichtig)
- Untersucher:in: 1,80 m, weiße Kleidung, leicht elliptischer Rumpf, frontal der Leistenregion zugewandt, 15 cm vom Tisch
- Frei schwebender Monitor mit stilisierter Kopfangiographie in Blickrichtung der Untersucher:in
- Systemkonsole, Raum mit Boden und zwei Wänden

## Steuerung

- Maus ziehen: Kamera um das Isozentrum rotieren
- Scrollen: zoomen · Rechte Maustaste: verschieben
- Regler/Buttons: LAO/RAO-Angulation des C-Bogens (±90°)
- Buttons: Kamera-Presets (frontal, seitlich, Kopfende, von oben, Übersicht)
- Beschriftungen ein-/ausblenden

## Starten

```bash
npm install
npm run dev
```

Danach im Browser die angezeigte Adresse öffnen (Standard: http://localhost:5173).

## Bauen

```bash
npm run build && npm run preview
```

Hinweis: Die Szene nutzt Tailwind via CDN (index.html) für die Steuerleiste – für Produktion auf die Vite/Tailwind-Integration umstellen.
